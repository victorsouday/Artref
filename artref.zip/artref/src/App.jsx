import { useState, useEffect, useRef } from "react";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, getDocs, deleteDoc, doc, query, where, updateDoc, onSnapshot, serverTimestamp, setDoc, getDoc, orderBy, limit } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCxZqJMe-fQGzkkRMtyscUZHWIpPL2DdxI",
  authDomain: "artref-1.firebaseapp.com",
  projectId: "artref-1",
  storageBucket: "artref-1.firebasestorage.app",
  messagingSenderId: "1015292107084",
  appId: "1:1015292107084:web:e9f3c26949defddbd697e9"
};

const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp);

const ADMIN_EMAIL = "vs.souday@gmail.com";
const ADMIN_PASSWORD = "Topaze176";
const TYPES = ["Peinture","Sculpture","Architecture","Mobilier","Art décoratif","Photographie"];

const APPLE_ICON = (<svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>);
const GOOGLE_ICON = (<svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.35-8.16 2.35-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>);

const DEFAULT_MOVEMENTS = [
  { id: "baroque", name: "Baroque", years: "1600–1750", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg/402px-Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg" },
  { id: "realisme", name: "Réalisme", years: "1840–1880", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Gustave_Courbet_-_A_Burial_at_Ornans_-_Google_Art_Project.jpg/1280px-Gustave_Courbet_-_A_Burial_at_Ornans_-_Google_Art_Project.jpg" },
  { id: "naturalisme", name: "Naturalisme", years: "1860–1900", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Jean-Fran%C3%A7ois_Millet_-_Gleaners_-_Google_Art_Project_2.jpg/1280px-Jean-Fran%C3%A7ois_Millet_-_Gleaners_-_Google_Art_Project_2.jpg" },
  { id: "preraphaelisme", name: "Préraphaélisme", years: "1848–1900", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/John_Everett_Millais_-_Ophelia_-_Google_Art_Project.jpg/1280px-John_Everett_Millais_-_Ophelia_-_Google_Art_Project.jpg" },
  { id: "impressionism", name: "Impressionnisme", years: "1860–1900", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Claude_Monet%2C_1840-1926%2C_Impression%2C_soleil_levant%2C_1872%2C_oil_on_canvas%2C_48_x_63_cm%2C_Mus%C3%A9e_Marmottan_Monet%2C_Paris.jpg/1280px-Claude_Monet%2C_1840-1926%2C_Impression%2C_soleil_levant%2C_1872%2C_oil_on_canvas%2C_48_x_63_cm%2C_Mus%C3%A9e_Marmottan_Monet%2C_Paris.jpg" },
  { id: "postimpressionnisme", name: "Post-impressionnisme", years: "1886–1910", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg/1280px-Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg" },
  { id: "pointillisme", name: "Pointillisme", years: "1886–1910", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/A_Sunday_on_La_Grande_Jatte%2C_Georges_Seurat%2C_1884.jpg/1280px-A_Sunday_on_La_Grande_Jatte%2C_Georges_Seurat%2C_1884.jpg" },
  { id: "symbolisme", name: "Symbolisme", years: "1880–1910", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Gustave_Moreau_-_Oedipus_and_the_Sphinx_-_Google_Art_Project.jpg/800px-Gustave_Moreau_-_Oedipus_and_the_Sphinx_-_Google_Art_Project.jpg" },
  { id: "artnouveau", name: "Art Nouveau", years: "1890–1910", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Klimt_-_The_Kiss.jpg/800px-Klimt_-_The_Kiss.jpg" },
  { id: "orientalisme", name: "Orientalisme", years: "1800–1900", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Delacroix-Femmes-d-Alger.jpg/1200px-Delacroix-Femmes-d-Alger.jpg" },
  { id: "fauvisme", name: "Fauvisme", years: "1904–1908", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Matisse-bonheur.jpg/1280px-Matisse-bonheur.jpg" },
  { id: "expressionnisme", name: "Expressionnisme", years: "1905–1933", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/The_Scream.jpg/800px-The_Scream.jpg" },
  { id: "cubisme", name: "Cubisme", years: "1907–1922", cover: "https://upload.wikimedia.org/wikipedia/en/4/4c/Les_Demoiselles_d%27Avignon.jpg" },
  { id: "futurisme", name: "Futurisme", years: "1909–1944", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Umberto_Boccioni%2C_1913%2C_Dynamism_of_a_Cyclist_%28Dinamismo_di_un_ciclista%29%2C_oil_on_canvas%2C_70_x_95_cm%2C_Mattioli_Collection%2C_Milan.jpg/1280px-Umberto_Boccioni%2C_1913%2C_Dynamism_of_a_Cyclist_%28Dinamismo_di_un_ciclista%29%2C_oil_on_canvas%2C_70_x_95_cm%2C_Mattioli_Collection%2C_Milan.jpg" },
  { id: "dadaisme", name: "Dadaïsme", years: "1916–1924", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Marcel_Duchamp%2C_1917%2C_Fountain%2C_photograph_by_Alfred_Stieglitz.jpg/800px-Marcel_Duchamp%2C_1917%2C_Fountain%2C_photograph_by_Alfred_Stieglitz.jpg" },
  { id: "surrealism", name: "Surréalisme", years: "1920–1950", cover: "https://upload.wikimedia.org/wikipedia/en/d/dd/The_Persistence_of_Memory.jpg" },
  { id: "constructivisme", name: "Constructivisme", years: "1913–1940", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Lazar_El_Lissitzky_-_Proun_19D_-_Google_Art_Project.jpg/800px-Lazar_El_Lissitzky_-_Proun_19D_-_Google_Art_Project.jpg" },
  { id: "suprematisme", name: "Suprématisme", years: "1915–1925", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Suprematist_Composition_-_Kazimir_Malevich.jpg/800px-Suprematist_Composition_-_Kazimir_Malevich.jpg" },
  { id: "bauhaus", name: "Bauhaus", years: "1919–1933", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/Bauhaus-Dessau_Hauptgeb%C3%A4ude.jpg/1280px-Bauhaus-Dessau_Hauptgeb%C3%A4ude.jpg" },
  { id: "destijl", name: "De Stijl", years: "1917–1931", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Tableau_I%2C_by_Piet_Mondriaan.jpg/800px-Tableau_I%2C_by_Piet_Mondriaan.jpg" },
  { id: "artdeco", name: "Art Déco", years: "1920–1940", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Chrysler_Building_by_David_Shankbone.jpg/800px-Chrysler_Building_by_David_Shankbone.jpg" },
  { id: "purisme", name: "Purisme", years: "1918–1926", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Fernand_L%C3%A9ger%2C_1919%2C_La_ville_%28The_City%29%2C_oil_on_canvas%2C_231.1_x_298.4_cm%2C_Philadelphia_Museum_of_Art.jpg/1280px-Fernand_L%C3%A9ger%2C_1919%2C_La_ville_%28The_City%29%2C_oil_on_canvas%2C_231.1_x_298.4_cm%2C_Philadelphia_Museum_of_Art.jpg" },
  { id: "expressionnisme_abstrait", name: "Expressionnisme abstrait", years: "1943–1965", cover: "https://upload.wikimedia.org/wikipedia/commons/a/a6/Jackson_Pollock._Numerous_Forms%2C_1945.jpg" },
  { id: "art_informel", name: "Art informel", years: "1940–1960", cover: "https://picsum.photos/seed/art_informel/600/400" },
  { id: "tachisme", name: "Tachisme", years: "1940–1960", cover: "https://picsum.photos/seed/tachisme/600/400" },
  { id: "color_field", name: "Color Field Painting", years: "1950–1970", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Mark_Rothko_-_No._61_%28Rust_and_Blue%29_%5BMuseum_of_Contemporary_Art%2C_Los_Angeles%5D.jpg/800px-Mark_Rothko_-_No._61_%28Rust_and_Blue%29_%5BMuseum_of_Contemporary_Art%2C_Los_Angeles%5D.jpg" },
  { id: "pop_art", name: "Pop Art", years: "1955–1970", cover: "https://upload.wikimedia.org/wikipedia/en/1/1a/Printedwarhol.jpg" },
  { id: "op_art", name: "Op Art", years: "1960–1970", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Victor_Vasarely%2C_1966%2C_Vega-Nor%2C_oil_on_canvas%2C_200_x_200_cm.jpg/800px-Victor_Vasarely%2C_1966%2C_Vega-Nor%2C_oil_on_canvas%2C_200_x_200_cm.jpg" },
  { id: "minimalism", name: "Minimalisme", years: "1960–présent", cover: "https://picsum.photos/seed/minimalism/600/400" },
  { id: "art_conceptuel", name: "Art conceptuel", years: "1960–présent", cover: "https://picsum.photos/seed/art_conceptuel/600/400" },
  { id: "land_art", name: "Land Art", years: "1960–présent", cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/Spiral-jetty-from-rozel-point.png/1280px-Spiral-jetty-from-rozel-point.png" },
  { id: "performance_art", name: "Performance Art", years: "1960–présent", cover: "https://picsum.photos/seed/performance/600/400" },
  { id: "arte_povera", name: "Arte Povera", years: "1967–présent", cover: "https://picsum.photos/seed/artepovera/600/400" },
  { id: "hyperrealisme", name: "Hyperréalisme", years: "1960–présent", cover: "https://picsum.photos/seed/hyperreal/600/400" },
  { id: "photorealisme", name: "Photoréalisme", years: "1960–présent", cover: "https://picsum.photos/seed/photoreal/600/400" },
  { id: "fluxus", name: "Fluxus", years: "1960–1978", cover: "https://picsum.photos/seed/fluxus/600/400" },
  { id: "installation", name: "Installation artistique", years: "1970–présent", cover: "https://picsum.photos/seed/install/600/400" },
  { id: "street_art", name: "Street Art", years: "1970–présent", cover: "https://picsum.photos/seed/streetart/600/400" },
  { id: "graffiti", name: "Graffiti", years: "1970–présent", cover: "https://picsum.photos/seed/graffiti/600/400" },
  { id: "neo_expressionnisme", name: "Néo-expressionnisme", years: "1970–1990", cover: "https://picsum.photos/seed/neoexp/600/400" },
  { id: "lowbrow", name: "Lowbrow Art", years: "1970–présent", cover: "https://picsum.photos/seed/lowbrow/600/400" },
  { id: "art_numerique", name: "Art numérique", years: "1980–présent", cover: "https://picsum.photos/seed/digital/600/400" },
  { id: "net_art", name: "Net Art", years: "1990–présent", cover: "https://picsum.photos/seed/netart/600/400" },
  { id: "glitch_art", name: "Glitch Art", years: "2000–présent", cover: "https://picsum.photos/seed/glitch/600/400" },
  { id: "nft_art", name: "NFT Art", years: "2017–présent", cover: "https://picsum.photos/seed/nftart/600/400" },
  { id: "bio_art", name: "Bio Art", years: "1990–présent", cover: "https://picsum.photos/seed/bioart/600/400" },
];

function useLS(key, init) {
  const [v, setV] = useState(() => { try { return JSON.parse(localStorage.getItem(key)) ?? init; } catch { return init; } });
  const set = (val) => { setV(val); localStorage.setItem(key, JSON.stringify(val)); };
  return [v, set];
}

function compressImage(dataUrl, maxW=600) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const ratio = Math.min(maxW / img.width, 1);
      canvas.width = img.width * ratio; canvas.height = img.height * ratio;
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.7));
    };
    img.src = dataUrl;
  });
}

function Avatar({ user, size=36, onClick }) {
  const s = { width:size, height:size, borderRadius:"50%", objectFit:"cover", cursor:onClick?"pointer":"default", flexShrink:0 };
  if (user?.avatar) return <img src={user.avatar} style={s} onClick={onClick} alt=""/>;
  return <div onClick={onClick} style={{...s, background:"#e74c3c", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Playfair Display',serif", fontWeight:700, fontSize:size*0.4, color:"#fff"}}>{user?.firstName?.[0]?.toUpperCase()||"?"}</div>;
}

async function registerPresence(userId) {
  try {
    const ref = doc(db, "presence", userId);
    await setDoc(ref, { online: true, lastSeen: Date.now() });
    window.addEventListener("beforeunload", () => setDoc(ref, { online: false, lastSeen: Date.now() }));
    setInterval(() => setDoc(ref, { online: true, lastSeen: Date.now() }), 30000);
  } catch(e) {}
}

async function getUserProfile(email) {
  try {
    const id = email.replace(/[^a-z0-9]/gi, "_");
    const snap = await getDoc(doc(db, "profiles", id));
    return snap.exists() ? snap.data() : null;
  } catch { return null; }
}

async function saveUserProfile(email, data) {
  try {
    const id = email.replace(/[^a-z0-9]/gi, "_");
    await setDoc(doc(db, "profiles", id), data, { merge: true });
  } catch(e) {}
}

export default function App() {
  const [showIntro, setShowIntro] = useState(() => !sessionStorage.getItem("artref_intro_seen"));
  const [introPhase, setIntroPhase] = useState(0);
  const [tab, setTab] = useState("explore");
  const [authMode, setAuthMode] = useState("login");
  const [user, setUser] = useLS("artref_user", null);
  const [saved, setSaved] = useLS("artref_saved", []);
  const [movements, setMovements] = useLS("artref_movements_v2", DEFAULT_MOVEMENTS);
  const [search, setSearch] = useState("");
  const [selectedMovement, setSelectedMovement] = useState(null);
  const [selectedRef, setSelectedRef] = useState(null);
  const [userRefs, setUserRefs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({ firstName:"", lastName:"", age:"", email:"", password:"" });
  const [formError, setFormError] = useState("");
  const [addingRef, setAddingRef] = useState(false);
  const [newRef, setNewRef] = useState({ title:"", artist:"", type:"Peinture", description:"" });
  const [photoPreview, setPhotoPreview] = useState(null);
  const [photoData, setPhotoData] = useState(null);
  const fileInputRef = useRef(null);
  const coverInputRef = useRef(null);
  const avatarInputRef = useRef(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [adminPanel, setAdminPanel] = useState(false);
  const [newMov, setNewMov] = useState({ name:"", years:"" });
  const [editMov, setEditMov] = useState(null);
  const [delMov, setDelMov] = useState(null);
  const [editingCover, setEditingCover] = useState(null);
  const [adminNotifs, setAdminNotifs] = useState([]);
  const [showNotifs, setShowNotifs] = useState(false);
  const [onlineCount, setOnlineCount] = useState(1);
  const [userNotifs, setUserNotifs] = useLS("artref_notifs", []);
  const [showUserNotifs, setShowUserNotifs] = useState(false);
  // Chat
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState("");
  const chatEndRef = useRef(null);
  // Profile
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({ bio:"" });
  const [viewingProfile, setViewingProfile] = useState(null);
  const [followers, setFollowers] = useLS("artref_followers", []);
  const [following, setFollowing] = useLS("artref_following", []);

  const admin = user?.email === ADMIN_EMAIL;
  const filtered = movements.filter(m => m.name.toLowerCase().includes(search.toLowerCase()));
  const unreadAdmin = adminNotifs.filter(n => !n.read).length;
  const unreadUser = userNotifs.filter(n => !n.read).length;

  // Intro
  useEffect(() => {
    if (!showIntro) return;
    const t1 = setTimeout(() => setIntroPhase(1), 1000);
    const t2 = setTimeout(() => setIntroPhase(2), 2000);
    const t3 = setTimeout(() => setIntroPhase(3), 3500);
    const t4 = setTimeout(() => { setShowIntro(false); sessionStorage.setItem("artref_intro_seen","1"); }, 4200);
    return () => [t1,t2,t3,t4].forEach(clearTimeout);
  }, [showIntro]);

  // Presence
  useEffect(() => { if (user) registerPresence(user.email.replace(/[^a-z0-9]/gi,"_")); }, [user?.email]);

  // Online count
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "presence"), (snap) => {
      const now = Date.now();
      setOnlineCount(Math.max(snap.docs.filter(d => d.data().online && (now - d.data().lastSeen) < 60000).length, 1));
    });
    return () => unsub();
  }, []);

  // Admin notifs
  useEffect(() => {
    if (!admin) return;
    const unsub = onSnapshot(collection(db, "adminNotifs"), (snap) => {
      const notifs = snap.docs.map(d => ({ ...d.data(), firestoreId: d.id }));
      notifs.sort((a,b) => (b.createdAt||0) - (a.createdAt||0));
      setAdminNotifs(notifs);
    });
    return () => unsub();
  }, [admin]);

  // User notifs
  useEffect(() => {
    if (!user || admin) return;
    const unsub = onSnapshot(collection(db, "userNotifs"), (snap) => {
      const notifs = snap.docs.map(d => ({ ...d.data(), id: d.id }));
      notifs.sort((a,b) => (b.createdAt||0) - (a.createdAt||0));
      const lastSeen = parseInt(localStorage.getItem("artref_notifs_lastseen")||"0");
      const fresh = notifs.filter(n => (n.createdAt||0) > lastSeen && n.addedById !== user.email);
      if (fresh.length > 0) setUserNotifs(fresh.slice(0,20));
    });
    return () => unsub();
  }, [user?.email, admin]);

  // Chat
  useEffect(() => {
    if (tab !== "chat") return;
    const unsub = onSnapshot(query(collection(db, "chat"), orderBy("createdAt","asc"), limit(100)), (snap) => {
      setChatMessages(snap.docs.map(d => ({ ...d.data(), id: d.id })));
      setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior:"smooth" }), 100);
    });
    return () => unsub();
  }, [tab]);

  async function sendMessage(e) {
    e.preventDefault();
    if (!chatInput.trim() || !user) return;
    try {
      await addDoc(collection(db, "chat"), {
        text: chatInput.trim(),
        userId: user.email,
        userName: `${user.firstName} ${user.lastName}`.trim(),
        userAvatar: user.avatar || null,
        createdAt: Date.now()
      });
      setChatInput("");
    } catch(e) {}
  }

  async function loadRefs(movement) {
    setLoading(true); setUserRefs([]);
    try {
      const q = query(collection(db, "refs"), where("movementId","==",movement.id));
      const snap = await getDocs(q);
      setUserRefs(snap.docs.map(d => ({ ...d.data(), firestoreId: d.id })).filter(r => r.approved !== false));
    } catch(e) { setUserRefs([]); }
    setLoading(false);
  }

  function handlePhoto(e) {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => { setPhotoPreview(ev.target.result); setPhotoData(ev.target.result); };
    reader.readAsDataURL(file);
  }

  async function handleCoverChange(e, movement) {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = async ev => {
      const compressed = await compressImage(ev.target.result, 800);
      setMovements(movements.map(m => m.id === movement.id ? { ...m, cover: compressed } : m));
      setEditingCover(null);
    };
    reader.readAsDataURL(file);
  }

  async function handleAvatarChange(e) {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = async ev => {
      const compressed = await compressImage(ev.target.result, 300);
      const updated = { ...user, avatar: compressed };
      setUser(updated);
      await saveUserProfile(user.email, { avatar: compressed, firstName: user.firstName, lastName: user.lastName });
    };
    reader.readAsDataURL(file);
  }

  async function saveProfile(e) {
    e.preventDefault();
    const updated = { ...user, bio: profileForm.bio };
    setUser(updated);
    await saveUserProfile(user.email, { bio: profileForm.bio, firstName: user.firstName, lastName: user.lastName, avatar: user.avatar || null });
    setEditingProfile(false);
  }

  async function viewProfile(email) {
    const profile = await getUserProfile(email);
    setViewingProfile(profile || { email, firstName: "Utilisateur", lastName: "" });
  }

  function toggleFollow(email) {
    if (following.includes(email)) setFollowing(following.filter(e => e !== email));
    else setFollowing([...following, email]);
  }

  async function submitRef(e) {
    e.preventDefault(); if (!newRef.title || !newRef.artist) return;
    setUploading(true);
    try {
      const photo = photoData ? await compressImage(photoData) : null;
      const data = { ...newRef, movementId: selectedMovement.id, movementName: selectedMovement.name,
        addedBy: user ? `${user.firstName} ${user.lastName}`.trim() : "Anonyme",
        addedById: user?.email||"anon", addedByAvatar: user?.avatar||null,
        photo, isUserRef:true, createdAt:Date.now(), approved:false };
      const ref = await addDoc(collection(db,"refs"), data);
      await addDoc(collection(db,"adminNotifs"), { type:"new_ref", read:false, title:newRef.title, artist:newRef.artist, movement:selectedMovement.name, addedBy:data.addedBy, addedById:data.addedById, refId:ref.id, photo, createdAt:Date.now() });
      await addDoc(collection(db,"userNotifs"), { type:"new_ref", title:newRef.title, artist:newRef.artist, movement:selectedMovement.name, addedBy:data.addedBy, addedById:data.addedById, createdAt:Date.now() });
      alert("✅ Référence envoyée ! Visible après validation de l'admin.");
    } catch(e) { console.error(e); }
    setNewRef({ title:"", artist:"", type:"Peinture", description:"" });
    setPhotoPreview(null); setPhotoData(null); setAddingRef(false); setUploading(false);
  }

  async function approveRef(notif) {
    try {
      await updateDoc(doc(db,"refs",notif.refId), { approved:true });
      await updateDoc(doc(db,"adminNotifs",notif.firestoreId), { read:true, approved:true });
      setAdminNotifs(prev => prev.map(n => n.firestoreId===notif.firestoreId ? {...n,read:true,approved:true} : n));
    } catch(e) {}
  }

  async function rejectRef(notif) {
    try {
      await deleteDoc(doc(db,"refs",notif.refId));
      await updateDoc(doc(db,"adminNotifs",notif.firestoreId), { read:true, rejected:true });
      setAdminNotifs(prev => prev.map(n => n.firestoreId===notif.firestoreId ? {...n,read:true,rejected:true} : n));
    } catch(e) {}
  }

  async function deleteRef(id) {
    try { await deleteDoc(doc(db,"refs",id)); setUserRefs(p => p.filter(r => r.firestoreId!==id)); } catch(e) {}
    setDeleteConfirm(null);
  }

  function toggleSave(ref) {
    if (!user) { setAuthMode("login"); return; }
    const id = ref.firestoreId||ref.id;
    if (saved.find(s => s.id===id)) setSaved(saved.filter(s => s.id!==id));
    else setSaved([...saved, { ...ref, id, movement:selectedMovement?.name }]);
  }

  function isSaved(ref) { return saved.some(s => s.id===(ref.firestoreId||ref.id)); }

  async function handleAuth(e) {
    e.preventDefault(); setFormError("");
    if (authMode==="signup") {
      if (!form.firstName||!form.lastName||!form.email||!form.password) { setFormError("Remplis tous les champs."); return; }
      const newUser = { firstName:form.firstName, lastName:form.lastName, age:form.age, email:form.email };
      setUser(newUser);
      await saveUserProfile(form.email, { firstName:form.firstName, lastName:form.lastName, email:form.email, bio:"", avatar:null });
      try { await addDoc(collection(db,"adminNotifs"), { type:"new_user", read:false, firstName:form.firstName, lastName:form.lastName, email:form.email, age:form.age, createdAt:Date.now() }); } catch(e) {}
    } else {
      if (!form.email||!form.password) { setFormError("Email et mot de passe requis."); return; }
      if (form.email===ADMIN_EMAIL && form.password===ADMIN_PASSWORD) {
        setUser({ firstName:"Victor", lastName:"Souday", email:ADMIN_EMAIL, isAdmin:true }); setAuthMode(null); return;
      }
      const profile = await getUserProfile(form.email);
      setUser(profile ? { ...profile, email:form.email } : { firstName:"Utilisateur", lastName:"", email:form.email });
    }
    setAuthMode(null);
  }

  function logout() { setUser(null); setSaved([]); }

  function addMovement(e) {
    e.preventDefault(); if (!newMov.name) return;
    const id = newMov.name.toLowerCase().replace(/[^a-z0-9]/g,"_")+"_"+Date.now();
    setMovements([...movements, { id, name:newMov.name, years:newMov.years, cover:`https://picsum.photos/seed/${id}/600/400` }]);
    setNewMov({ name:"", years:"" });
  }

  function saveEditMov(e) {
    e.preventDefault();
    setMovements(movements.map(m => m.id===editMov.id ? editMov : m));
    setEditMov(null);
  }

  const CSS = `
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500&display=swap');
    *{box-sizing:border-box;margin:0;padding:0;}
    body{background:#0a0a0a;}
    input,select,textarea{font-family:'DM Sans',sans-serif;}
    ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:#111}::-webkit-scrollbar-thumb{background:#e74c3c}
    @keyframes pulse{0%,100%{opacity:.4}50%{opacity:.8}}
    @keyframes slideIn{from{transform:translateY(-10px);opacity:0}to{transform:translateY(0);opacity:1}}
    @keyframes fadeIn{from{opacity:0}to{opacity:1}}
    @keyframes splitLeft{from{transform:translateX(0);opacity:1}to{transform:translateX(-120px);opacity:0}}
    @keyframes splitRight{from{transform:translateX(0);opacity:1}to{transform:translateX(120px);opacity:0}}
    @keyframes designedIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
    @keyframes designedOut{from{opacity:1}to{opacity:0}}
  `;

  const S = {
    app:{minHeight:"100vh",background:"#0a0a0a",fontFamily:"'DM Sans',sans-serif",color:"#fff",paddingBottom:80},
    header:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 20px",borderBottom:"1px solid #1a1a1a",position:"sticky",top:0,background:"#0a0a0a",zIndex:100},
    logo:{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900,letterSpacing:4,color:"#e74c3c"},
    headerTitle:{fontFamily:"'Playfair Display',serif",fontSize:18,fontWeight:700,flex:1,textAlign:"center"},
    back:{background:"none",border:"none",color:"#e74c3c",fontSize:14,cursor:"pointer"},
    addBtn:{background:"#e74c3c",border:"none",color:"#fff",fontSize:13,padding:"6px 14px",borderRadius:20,cursor:"pointer"},
    loginBtn:{background:"none",border:"1px solid #e74c3c",color:"#e74c3c",padding:"6px 16px",borderRadius:20,fontSize:13,cursor:"pointer"},
    adminBtn:{background:"none",border:"1px solid #e74c3c",color:"#e74c3c",padding:"6px 12px",borderRadius:20,fontSize:13,cursor:"pointer"},
    bellWrap:{position:"relative",cursor:"pointer"},
    bell:{background:"none",border:"none",fontSize:20,cursor:"pointer",color:"#fff"},
    bellBadge:{position:"absolute",top:-4,right:-4,background:"#e74c3c",color:"#fff",fontSize:9,fontWeight:700,width:16,height:16,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"},
    onlineDot:{display:"flex",alignItems:"center",gap:5,fontSize:11,color:"#4ade80"},
    notifPanel:{position:"absolute",top:56,right:12,width:320,maxHeight:420,overflowY:"auto",background:"#111",border:"1px solid #222",borderRadius:16,zIndex:200,animation:"slideIn .2s ease"},
    notifItem:{padding:"14px 16px",borderBottom:"1px solid #1a1a1a",display:"flex",flexDirection:"column",gap:6},
    notifTitle:{fontSize:13,fontWeight:600,color:"#fff"},
    notifSub:{fontSize:11,color:"#888"},
    notifActions:{display:"flex",gap:8,marginTop:4},
    notifApprove:{background:"#16a34a",border:"none",color:"#fff",padding:"5px 14px",borderRadius:10,fontSize:12,cursor:"pointer",fontWeight:600},
    notifReject:{background:"#7f1d1d",border:"none",color:"#fff",padding:"5px 14px",borderRadius:10,fontSize:12,cursor:"pointer"},
    searchWrap:{display:"flex",alignItems:"center",margin:"12px 12px 4px",background:"#111",borderRadius:30,padding:"10px 16px",border:"1px solid #1e1e1e",gap:8},
    searchInput:{flex:1,background:"none",border:"none",color:"#fff",fontSize:14,outline:"none"},
    searchClear:{background:"none",border:"none",color:"#555",fontSize:14,cursor:"pointer"},
    noResult:{display:"flex",flexDirection:"column",alignItems:"center",padding:"60px 20px",textAlign:"center"},
    grid:{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8,padding:"12px"},
    movCard:{position:"relative",borderRadius:12,overflow:"hidden",cursor:"pointer",aspectRatio:"3/2"},
    movImg:{width:"100%",height:"100%",objectFit:"cover",filter:"brightness(0.45)"},
    movOverlay:{position:"absolute",bottom:0,left:0,right:0,padding:"16px 14px",background:"linear-gradient(transparent,rgba(0,0,0,0.85))"},
    movName:{fontFamily:"'Playfair Display',serif",fontSize:15,fontWeight:700},
    movYears:{fontSize:11,color:"#e74c3c",marginTop:2},
    masonry:{columns:2,columnGap:8,padding:"12px"},
    card:{breakInside:"avoid",marginBottom:8,background:"#111",borderRadius:12,overflow:"hidden",cursor:"pointer"},
    cardImg:{width:"100%",display:"block",objectFit:"cover"},
    cardTopBar:{position:"absolute",top:8,left:8,right:8,display:"flex",justifyContent:"space-between",alignItems:"flex-start"},
    typeTag:{background:"rgba(231,76,60,0.85)",color:"#fff",fontSize:9,padding:"3px 8px",borderRadius:10,fontWeight:500},
    iconBtn:{background:"rgba(0,0,0,0.55)",border:"none",fontSize:15,cursor:"pointer",padding:"3px 7px",borderRadius:16,color:"#fff",lineHeight:1},
    commBadge:{position:"absolute",bottom:8,left:8,background:"rgba(0,0,0,0.7)",color:"#e74c3c",fontSize:9,padding:"3px 8px",borderRadius:10,fontWeight:600,letterSpacing:1},
    cardBody:{padding:"10px 12px 12px"},
    cardTitle:{fontFamily:"'Playfair Display',serif",fontSize:13,fontWeight:700,marginBottom:3,lineHeight:1.3},
    cardArtist:{fontSize:11,color:"#e74c3c",marginBottom:5},
    cardDesc:{fontSize:11,color:"#888",lineHeight:1.5},
    addedBy:{fontSize:10,color:"#555",marginTop:4,fontStyle:"italic"},
    mvBadge:{background:"#1a1a1a",color:"#e74c3c",fontSize:9,padding:"2px 8px",borderRadius:10,display:"inline-block",marginBottom:4},
    unsaveBtn:{background:"none",border:"1px solid #2a2a2a",color:"#666",fontSize:11,padding:"4px 10px",borderRadius:10,cursor:"pointer",marginTop:8},
    nav:{position:"fixed",bottom:0,left:0,right:0,background:"#0a0a0a",borderTop:"1px solid #1a1a1a",display:"flex",justifyContent:"space-around",padding:"10px 0 16px",zIndex:100},
    navBtn:{background:"none",border:"none",color:"#555",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:3,fontSize:18},
    navBtnOn:{background:"none",border:"none",color:"#e74c3c",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:3,fontSize:18},
    navLabel:{fontSize:9},
    authWrap:{minHeight:"100vh",background:"#0a0a0a",display:"flex",alignItems:"center",justifyContent:"center",padding:20},
    authCard:{background:"#111",borderRadius:20,padding:"36px 28px",width:"100%",maxWidth:400,border:"1px solid #1e1e1e"},
    authSub:{color:"#555",fontSize:13,textAlign:"center",marginTop:4,marginBottom:24,fontStyle:"italic"},
    authTabs:{display:"flex",background:"#0a0a0a",borderRadius:30,padding:4,marginBottom:24,gap:4},
    authTab:{flex:1,background:"none",border:"none",color:"#666",padding:"8px 0",borderRadius:24,cursor:"pointer",fontSize:14},
    authTabOn:{flex:1,background:"#e74c3c",border:"none",color:"#fff",padding:"8px 0",borderRadius:24,cursor:"pointer",fontSize:14,fontWeight:500},
    row:{display:"flex",gap:10},
    input:{flex:1,background:"#0a0a0a",border:"1px solid #222",borderRadius:10,padding:"12px 14px",color:"#fff",fontSize:14,outline:"none"},
    inputFull:{width:"100%",background:"#0a0a0a",border:"1px solid #222",borderRadius:10,padding:"12px 14px",color:"#fff",fontSize:14,outline:"none"},
    btnRed:{width:"100%",background:"#e74c3c",border:"none",color:"#fff",padding:"13px 0",borderRadius:12,fontSize:15,fontWeight:600,cursor:"pointer",marginTop:4},
    btnOutline:{flex:1,background:"none",border:"1px solid #333",color:"#aaa",padding:"12px 0",borderRadius:12,fontSize:14,cursor:"pointer"},
    divider:{textAlign:"center",color:"#333",margin:"16px 0",fontSize:12},
    btnGoogle:{width:"100%",background:"#fff",border:"none",color:"#111",padding:"12px 0",borderRadius:12,fontSize:14,fontWeight:500,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:10},
    btnApple:{width:"100%",background:"#000",border:"1px solid #333",color:"#fff",padding:"12px 0",borderRadius:12,fontSize:14,fontWeight:500,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:10,marginTop:8},
    skipBtn:{display:"block",width:"100%",background:"none",border:"none",color:"#555",fontSize:13,cursor:"pointer",marginTop:16,textAlign:"center"},
    profileWrap:{padding:"24px 20px 100px",display:"flex",flexDirection:"column",alignItems:"center"},
    avatarWrap:{position:"relative",cursor:"pointer"},
    adminBadge:{position:"absolute",bottom:-4,right:-4,background:"#e74c3c",color:"#fff",fontSize:9,padding:"2px 6px",borderRadius:8,fontWeight:700,letterSpacing:1},
    adminPanelBtn:{marginTop:16,background:"#1a1a1a",border:"1px solid #e74c3c",color:"#e74c3c",padding:"10px 24px",borderRadius:20,cursor:"pointer",fontSize:13,fontWeight:600},
    profileName:{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:700,marginTop:16},
    profileEmail:{color:"#555",fontSize:13,marginTop:4},
    profileBio:{color:"#888",fontSize:13,marginTop:8,textAlign:"center",maxWidth:280,lineHeight:1.5},
    savedHeader:{fontSize:11,fontWeight:600,color:"#666",marginBottom:16,textTransform:"uppercase",letterSpacing:2},
    logoutBtn:{marginTop:32,background:"none",border:"1px solid #222",color:"#555",padding:"10px 28px",borderRadius:20,cursor:"pointer",fontSize:13},
    modalBack:{position:"fixed",inset:0,background:"rgba(0,0,0,0.88)",zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",padding:20},
    modal:{background:"#111",borderRadius:20,padding:28,width:"100%",maxWidth:400,border:"1px solid #222",display:"flex",flexDirection:"column",gap:12},
    modalTitle:{fontFamily:"'Playfair Display',serif",fontSize:20,marginBottom:4},
    photoUpload:{width:"100%",height:160,background:"#0a0a0a",border:"1px dashed #333",borderRadius:10,cursor:"pointer",overflow:"hidden"},
    photoPlaceholder:{width:"100%",height:"100%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"},
    adminSection:{background:"#111",borderRadius:16,padding:20,marginBottom:16,border:"1px solid #1e1e1e"},
    adminSectionTitle:{fontSize:11,fontWeight:700,color:"#e74c3c",textTransform:"uppercase",letterSpacing:2,marginBottom:16},
    adminRow:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:"1px solid #1a1a1a"},
    adminEditBtn:{background:"none",border:"1px solid #333",color:"#aaa",padding:"4px 8px",borderRadius:8,cursor:"pointer",fontSize:13},
    adminDelBtn:{background:"none",border:"1px solid #333",color:"#e74c3c",padding:"4px 8px",borderRadius:8,cursor:"pointer",fontSize:13},
    chatWrap:{display:"flex",flexDirection:"column",height:"calc(100vh - 140px)",padding:0},
    chatMessages:{flex:1,overflowY:"auto",padding:"12px"},
    chatBubble:{display:"flex",gap:10,marginBottom:14,alignItems:"flex-end"},
    chatBubbleOwn:{flexDirection:"row-reverse"},
    chatText:{background:"#1a1a1a",borderRadius:16,padding:"10px 14px",fontSize:13,maxWidth:"72%",lineHeight:1.5},
    chatTextOwn:{background:"#e74c3c",borderRadius:16,padding:"10px 14px",fontSize:13,maxWidth:"72%",lineHeight:1.5},
    chatName:{fontSize:10,color:"#555",marginBottom:3},
    chatInputWrap:{display:"flex",gap:8,padding:"12px 16px",borderTop:"1px solid #1a1a1a",background:"#0a0a0a"},
    chatInput:{flex:1,background:"#111",border:"1px solid #222",borderRadius:24,padding:"10px 16px",color:"#fff",fontSize:14,outline:"none"},
    chatSend:{background:"#e74c3c",border:"none",color:"#fff",padding:"10px 18px",borderRadius:24,cursor:"pointer",fontSize:14,fontWeight:600},
  };

  // ── INTRO ──
  if (showIntro) return (
    <div style={{minHeight:"100vh",background:"#0a0a0a",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",overflow:"hidden"}}>
      <style>{CSS}</style>
      {introPhase < 2 && (
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",position:"relative"}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:180,fontWeight:900,color:"#e74c3c",lineHeight:1,overflow:"hidden",width:70,textAlign:"right",animation:introPhase===1?"splitLeft 0.8s ease forwards":"fadeIn 0.6s ease forwards"}}>A</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:180,fontWeight:900,color:"#e74c3c",lineHeight:1,overflow:"hidden",width:70,textAlign:"left",marginLeft:-70,animation:introPhase===1?"splitRight 0.8s ease forwards":"fadeIn 0.6s ease forwards"}}>A</div>
        </div>
      )}
      {introPhase===2&&(<div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:8,animation:"designedIn 0.6s ease forwards"}}><div style={{fontFamily:"'DM Sans',sans-serif",fontSize:13,color:"#555",letterSpacing:4,textTransform:"uppercase"}}>Designed by</div><div style={{fontFamily:"'Playfair Display',serif",fontSize:36,fontWeight:900,color:"#e74c3c",letterSpacing:2}}>Victor Souday</div></div>)}
      {introPhase===3&&(<div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:8,animation:"designedOut 0.6s ease forwards"}}><div style={{fontFamily:"'DM Sans',sans-serif",fontSize:13,color:"#555",letterSpacing:4,textTransform:"uppercase"}}>Designed by</div><div style={{fontFamily:"'Playfair Display',serif",fontSize:36,fontWeight:900,color:"#e74c3c",letterSpacing:2}}>Victor Souday</div></div>)}
    </div>
  );

  // ── AUTH ──
  if (authMode && !user) return (
    <div style={S.authWrap}><style>{CSS}</style>
      <div style={S.authCard}>
        <div style={S.logo}>ARTREF</div>
        <p style={S.authSub}>La bibliothèque vivante de l'art</p>
        <div style={S.authTabs}>
          <button style={authMode==="login"?S.authTabOn:S.authTab} onClick={()=>setAuthMode("login")}>Connexion</button>
          <button style={authMode==="signup"?S.authTabOn:S.authTab} onClick={()=>setAuthMode("signup")}>Inscription</button>
        </div>
        <form onSubmit={handleAuth} style={{display:"flex",flexDirection:"column",gap:10}}>
          {authMode==="signup"&&<><div style={S.row}><input style={S.input} placeholder="Prénom" value={form.firstName} onChange={e=>setForm({...form,firstName:e.target.value})}/><input style={S.input} placeholder="Nom" value={form.lastName} onChange={e=>setForm({...form,lastName:e.target.value})}/></div><input style={S.inputFull} placeholder="Âge" type="number" value={form.age} onChange={e=>setForm({...form,age:e.target.value})}/></>}
          <input style={S.inputFull} placeholder="Adresse mail" type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
          <input style={S.inputFull} placeholder="Mot de passe" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
          {formError&&<p style={{color:"#e74c3c",fontSize:12,textAlign:"center"}}>{formError}</p>}
          <button style={S.btnRed} type="submit">{authMode==="login"?"Se connecter":"Créer mon compte"}</button>
        </form>
        <div style={S.divider}>ou</div>
        <button style={S.btnGoogle} onClick={()=>{setUser({firstName:"Utilisateur",lastName:"Google",email:"google@user.com"});setAuthMode(null);}}>{GOOGLE_ICON}<span>Continuer avec Google</span></button>
        <button style={S.btnApple} onClick={()=>{setUser({firstName:"Utilisateur",lastName:"Apple",email:"apple@user.com"});setAuthMode(null);}}>{APPLE_ICON}<span>Continuer avec Apple</span></button>
        <button style={S.skipBtn} onClick={()=>setAuthMode(null)}>Continuer sans compte →</button>
      </div>
    </div>
  );

  // ── ADMIN PANEL ──
  if (adminPanel && admin) return (
    <div style={S.app}><style>{CSS}</style>
      <header style={S.header}>
        <button style={S.back} onClick={()=>setAdminPanel(false)}>← Retour</button>
        <span style={S.headerTitle}>Panel Admin</span>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={S.onlineDot}><span style={{width:7,height:7,borderRadius:"50%",background:"#4ade80",display:"inline-block"}}></span>{onlineCount} en ligne</span>
          <div style={S.bellWrap} onClick={()=>setShowNotifs(!showNotifs)}>
            <button style={S.bell}>🔔</button>
            {unreadAdmin>0&&<div style={S.bellBadge}>{unreadAdmin}</div>}
          </div>
        </div>
      </header>
      {showNotifs&&(
        <div style={S.notifPanel}>
          <div style={{padding:"14px 16px",borderBottom:"1px solid #222",fontSize:12,color:"#e74c3c",fontWeight:700,textTransform:"uppercase",letterSpacing:1}}>Notifications ({adminNotifs.length})</div>
          {adminNotifs.length===0&&<div style={{padding:20,color:"#555",fontSize:13,textAlign:"center"}}>Aucune notification</div>}
          {adminNotifs.map(n=>(
            <div key={n.firestoreId} style={{...S.notifItem,background:n.read?"transparent":"rgba(231,76,60,0.05)"}}>
              {n.type==="new_ref"&&<><div style={S.notifTitle}>📎 Nouvelle référence à valider</div><div style={S.notifSub}>"{n.title}" — {n.artist}</div><div style={S.notifSub}>Mouvement : {n.movement}</div><div style={S.notifSub}>Par : {n.addedBy}</div>{n.photo&&<img src={n.photo} style={{width:"100%",height:80,objectFit:"cover",borderRadius:8,marginTop:4}} alt=""/>}{!n.approved&&!n.rejected&&(<div style={S.notifActions}><button style={S.notifApprove} onClick={()=>approveRef(n)}>✅ Approuver</button><button style={S.notifReject} onClick={()=>rejectRef(n)}>❌ Refuser</button></div>)}{n.approved&&<div style={{fontSize:11,color:"#4ade80",marginTop:4}}>✅ Approuvée</div>}{n.rejected&&<div style={{fontSize:11,color:"#f87171",marginTop:4}}>❌ Refusée</div>}</>}
              {n.type==="new_user"&&<><div style={S.notifTitle}>👤 Nouvelle inscription</div><div style={S.notifSub}>{n.firstName} {n.lastName}</div><div style={S.notifSub}>{n.email}{n.age?` · ${n.age} ans`:""}</div></>}
              <div style={{fontSize:10,color:"#444",marginTop:2}}>{n.createdAt?new Date(n.createdAt).toLocaleString("fr-FR"):""}</div>
            </div>
          ))}
        </div>
      )}
      <div style={{padding:"16px 16px 100px"}}>
        <div style={S.adminSection}>
          <div style={S.adminSectionTitle}>Ajouter un mouvement</div>
          <form onSubmit={addMovement} style={{display:"flex",flexDirection:"column",gap:10}}>
            <input style={S.inputFull} placeholder="Nom du mouvement *" value={newMov.name} onChange={e=>setNewMov({...newMov,name:e.target.value})}/>
            <input style={S.inputFull} placeholder="Période (ex: 1920–1940)" value={newMov.years} onChange={e=>setNewMov({...newMov,years:e.target.value})}/>
            <button style={S.btnRed} type="submit">Ajouter</button>
          </form>
        </div>
        {editMov&&(<div style={S.modalBack}><div style={S.modal}><h3 style={S.modalTitle}>Modifier</h3><form onSubmit={saveEditMov} style={{display:"flex",flexDirection:"column",gap:10}}><input style={S.inputFull} value={editMov.name} onChange={e=>setEditMov({...editMov,name:e.target.value})}/><input style={S.inputFull} value={editMov.years} onChange={e=>setEditMov({...editMov,years:e.target.value})}/><div style={S.row}><button style={S.btnRed} type="submit">Sauvegarder</button><button style={S.btnOutline} type="button" onClick={()=>setEditMov(null)}>Annuler</button></div></form></div></div>)}
        {delMov&&(<div style={S.modalBack}><div style={{...S.modal,gap:16,alignItems:"center"}}><span style={{fontSize:36}}>🗑️</span><p style={{color:"#fff",textAlign:"center"}}>Supprimer ce mouvement ?</p><div style={S.row}><button style={{...S.btnRed,flex:1}} onClick={()=>{setMovements(movements.filter(m=>m.id!==delMov));setDelMov(null);}}>Supprimer</button><button style={{...S.btnOutline,flex:1}} onClick={()=>setDelMov(null)}>Annuler</button></div></div></div>)}
        <div style={S.adminSection}>
          <div style={S.adminSectionTitle}>Mouvements ({movements.length})</div>
          {movements.map(m=>(
            <div key={m.id} style={S.adminRow}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <img src={m.cover||`https://picsum.photos/seed/mv-${m.id}/60/40`} style={{width:50,height:34,objectFit:"cover",borderRadius:6}} alt="" onError={e=>{e.target.src=`https://picsum.photos/seed/mv-${m.id}/60/40`;}}/>
                <div><div style={{color:"#fff",fontSize:13,fontWeight:600}}>{m.name}</div><div style={{color:"#666",fontSize:11}}>{m.years}</div></div>
              </div>
              <div style={{display:"flex",gap:6}}>
                <button style={S.adminEditBtn} onClick={()=>{ setEditingCover(m); coverInputRef.current?.click(); }} title="Changer photo">🖼️</button>
                <button style={S.adminEditBtn} onClick={()=>setEditMov({...m})}>✏️</button>
                <button style={S.adminDelBtn} onClick={()=>setDelMov(m.id)}>🗑️</button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <input ref={coverInputRef} type="file" accept="image/*" style={{display:"none"}} onChange={e=>editingCover&&handleCoverChange(e,editingCover)}/>
      <nav style={S.nav}>
        <button style={S.navBtn} onClick={()=>{setAdminPanel(false);setTab("explore");}}><span>⊞</span><span style={S.navLabel}>Explorer</span></button>
        <button style={S.navBtn} onClick={()=>{setAdminPanel(false);setTab("chat");}}><span>💬</span><span style={S.navLabel}>Chat</span></button>
        <button style={S.navBtn} onClick={()=>{setAdminPanel(false);setTab("profile");}}><span>◯</span><span style={S.navLabel}>Profil</span></button>
      </nav>
    </div>
  );

  // ── VIEWING OTHER PROFILE ──
  if (viewingProfile) return (
    <div style={S.app}><style>{CSS}</style>
      <header style={S.header}>
        <button style={S.back} onClick={()=>setViewingProfile(null)}>← Retour</button>
        <span style={S.headerTitle}>Profil</span>
        <span></span>
      </header>
      <div style={S.profileWrap}>
        <Avatar user={viewingProfile} size={80}/>
        <div style={S.profileName}>{viewingProfile.firstName} {viewingProfile.lastName}</div>
        {viewingProfile.bio&&<div style={S.profileBio}>{viewingProfile.bio}</div>}
        {user&&viewingProfile.email!==user.email&&(
          <button style={{...S.adminPanelBtn,marginTop:20,background:following.includes(viewingProfile.email)?"#1a1a1a":"#e74c3c",borderColor:following.includes(viewingProfile.email)?"#333":"#e74c3c",color:"#fff"}} onClick={()=>toggleFollow(viewingProfile.email)}>
            {following.includes(viewingProfile.email)?"✓ Abonné":"+ S'abonner"}
          </button>
        )}
      </div>
    </div>
  );

  // ── MOVEMENT DETAIL ──
  if (selectedMovement) return (
    <div style={S.app}><style>{CSS}</style>
      <header style={S.header}>
        <button style={S.back} onClick={()=>{setSelectedMovement(null);setUserRefs([]);}}>← Retour</button>
        <span style={S.headerTitle}>{selectedMovement.name}</span>
        <button style={S.addBtn} onClick={()=>{if(!user){setAuthMode("login");return;}setAddingRef(true);}}>+ Ajouter</button>
      </header>

      {addingRef&&(<div style={S.modalBack}><div style={S.modal}><h3 style={S.modalTitle}>Ajouter une référence</h3><p style={{fontSize:12,color:"#888",marginTop:-8}}>Visible après validation admin.</p><form onSubmit={submitRef} style={{display:"flex",flexDirection:"column",gap:10}}><div style={S.photoUpload} onClick={()=>fileInputRef.current?.click()}>{photoPreview?<img src={photoPreview} alt="" style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:10}}/>:<div style={S.photoPlaceholder}><span style={{fontSize:28}}>📷</span><span style={{fontSize:12,color:"#666",marginTop:6}}>Ajouter une photo</span></div>}<input ref={fileInputRef} type="file" accept="image/*" style={{display:"none"}} onChange={handlePhoto}/></div><input style={S.inputFull} placeholder="Titre de l'œuvre *" value={newRef.title} onChange={e=>setNewRef({...newRef,title:e.target.value})}/><input style={S.inputFull} placeholder="Artiste / Créateur *" value={newRef.artist} onChange={e=>setNewRef({...newRef,artist:e.target.value})}/><select style={S.inputFull} value={newRef.type} onChange={e=>setNewRef({...newRef,type:e.target.value})}>{TYPES.map(t=><option key={t}>{t}</option>)}</select><textarea style={{...S.inputFull,height:72,resize:"vertical"}} placeholder="Description (optionnel)" value={newRef.description} onChange={e=>setNewRef({...newRef,description:e.target.value})}/><div style={S.row}><button style={S.btnRed} type="submit" disabled={uploading}>{uploading?"Envoi...":"Soumettre"}</button><button style={S.btnOutline} type="button" onClick={()=>{setAddingRef(false);setPhotoPreview(null);setPhotoData(null);}}>Annuler</button></div></form></div></div>)}

      {deleteConfirm&&(<div style={S.modalBack}><div style={{...S.modal,gap:16,alignItems:"center"}}><span style={{fontSize:36}}>🗑️</span><p style={{color:"#fff",textAlign:"center"}}>Supprimer cette référence ?</p><div style={S.row}><button style={{...S.btnRed,flex:1}} onClick={()=>deleteRef(deleteConfirm)}>Supprimer</button><button style={{...S.btnOutline,flex:1}} onClick={()=>setDeleteConfirm(null)}>Annuler</button></div></div></div>)}

      {selectedRef&&(<div style={S.modalBack} onClick={()=>setSelectedRef(null)}><div style={{...S.modal,gap:0,padding:0,overflow:"hidden",maxHeight:"85vh",overflowY:"auto"}} onClick={e=>e.stopPropagation()}><div style={{position:"relative"}}><img src={selectedRef.photo||`https://picsum.photos/seed/${selectedMovement.id}-${selectedRef.id}/400/500`} alt={selectedRef.title} style={{width:"100%",maxHeight:280,objectFit:"cover"}} onError={e=>{e.target.src=`https://picsum.photos/seed/${selectedRef.id}/400/500`;}} /><button style={{position:"absolute",top:12,right:12,background:"rgba(0,0,0,0.6)",border:"none",color:"#fff",fontSize:18,width:32,height:32,borderRadius:"50%",cursor:"pointer"}} onClick={()=>setSelectedRef(null)}>✕</button><span style={{...S.typeTag,position:"absolute",top:12,left:12}}>{selectedRef.type}</span>{selectedRef.isUserRef&&<div style={S.commBadge}>✦ Communauté</div>}</div><div style={{padding:"20px 20px 28px",display:"flex",flexDirection:"column",gap:10}}><div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:700,lineHeight:1.3}}>{selectedRef.title}</div><div style={{fontSize:13,color:"#e74c3c",fontWeight:500}}>{selectedRef.artist}{selectedRef.year?` · ${selectedRef.year}`:""}</div>{selectedRef.description&&<div style={{fontSize:13,color:"#aaa",lineHeight:1.6,marginTop:4}}>{selectedRef.description}</div>}{selectedRef.isUserRef&&<div style={{display:"flex",alignItems:"center",gap:8,marginTop:4,cursor:"pointer"}} onClick={()=>viewProfile(selectedRef.addedById)}><Avatar user={{firstName:selectedRef.addedBy,avatar:selectedRef.addedByAvatar}} size={24}/><span style={{fontSize:11,color:"#555"}}>Ajouté par {selectedRef.addedBy}</span></div>}<div style={{display:"flex",gap:10,marginTop:8}}><button style={{...S.btnRed,marginTop:0,flex:1,padding:"11px 0",fontSize:14,background:isSaved(selectedRef)?"#333":"#e74c3c"}} onClick={()=>toggleSave(selectedRef)}>{isSaved(selectedRef)?"♥ Sauvegardé":"♡ Sauvegarder"}</button>{user&&selectedRef.isUserRef&&(selectedRef.addedById===user.email||admin)&&(<button style={{...S.btnOutline,flex:"0 0 auto",padding:"11px 16px",borderColor:"#e74c3c",color:"#e74c3c"}} onClick={()=>{setDeleteConfirm(selectedRef.firestoreId);setSelectedRef(null);}}>🗑️</button>)}</div></div></div></div>)}

      <div style={S.masonry}>
        {loading&&Array.from({length:6}).map((_,i)=>(<div key={i} style={{...S.card,height:[260,320,280,300,240,350][i],animation:"pulse 1.5s infinite"}}/>))}
        {!loading&&userRefs.length===0&&(<div style={{gridColumn:"1/-1",textAlign:"center",padding:"60px 20px",color:"#555"}}><p style={{fontSize:32}}>🖼️</p><p style={{marginTop:12,fontSize:14}}>Aucune référence pour l'instant.</p><p style={{fontSize:12,marginTop:6,color:"#444"}}>Sois le premier à en ajouter !</p></div>)}
        {!loading&&userRefs.map(ref=>{
          const img = ref.photo||`https://picsum.photos/seed/${selectedMovement.id}-${ref.id}/400/500`;
          return (<div key={ref.firestoreId||ref.id} style={S.card} onClick={()=>setSelectedRef(ref)}><div style={{position:"relative"}}><img src={img} alt={ref.title} style={S.cardImg} onError={e=>{e.target.src=`https://picsum.photos/seed/${ref.id}/400/500`;}} /><div style={S.cardTopBar}><span style={S.typeTag}>{ref.type}</span><button style={{...S.iconBtn,color:isSaved(ref)?"#e74c3c":"#fff"}} onClick={e=>{e.stopPropagation();toggleSave(ref);}}>{isSaved(ref)?"♥":"♡"}</button></div>{ref.isUserRef&&<div style={S.commBadge}>✦ Communauté</div>}</div><div style={S.cardBody}><div style={S.cardTitle}>{ref.title}</div><div style={S.cardArtist}>{ref.artist}{ref.year?` · ${ref.year}`:""}</div></div></div>);
        })}
      </div>
    </div>
  );

  // ── CHAT ──
  if (tab==="chat") return (
    <div style={{...S.app,display:"flex",flexDirection:"column"}}><style>{CSS}</style>
      <header style={S.header}>
        <span style={S.logo}>ARTREF</span>
        <span style={S.headerTitle}>Chat</span>
        <span style={{fontSize:11,color:"#4ade80",display:"flex",alignItems:"center",gap:4}}><span style={{width:6,height:6,borderRadius:"50%",background:"#4ade80",display:"inline-block"}}></span>{onlineCount} en ligne</span>
      </header>
      {!user ? (
        <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,padding:20}}>
          <p style={{fontSize:32}}>💬</p>
          <p style={{color:"#666",fontSize:14,textAlign:"center"}}>Connecte-toi pour accéder au chat.</p>
          <button style={{...S.btnRed,width:200}} onClick={()=>setAuthMode("login")}>Se connecter</button>
        </div>
      ) : (
        <div style={S.chatWrap}>
          <div style={S.chatMessages}>
            {chatMessages.length===0&&<div style={{textAlign:"center",color:"#444",padding:"40px 20px",fontSize:13}}>Aucun message pour l'instant. Sois le premier à écrire !</div>}
            {chatMessages.map(msg=>{
              const isOwn = msg.userId===user.email;
              return (
                <div key={msg.id} style={{...S.chatBubble,...(isOwn?S.chatBubbleOwn:{})}}>
                  {!isOwn&&<Avatar user={{firstName:msg.userName,avatar:msg.userAvatar}} size={32} onClick={()=>viewProfile(msg.userId)}/>}
                  <div>
                    {!isOwn&&<div style={S.chatName}>{msg.userName}</div>}
                    <div style={isOwn?S.chatTextOwn:S.chatText}>{msg.text}</div>
                  </div>
                  {isOwn&&<Avatar user={user} size={32}/>}
                </div>
              );
            })}
            <div ref={chatEndRef}/>
          </div>
          <form onSubmit={sendMessage} style={S.chatInputWrap}>
            <input style={S.chatInput} placeholder="Écris un message..." value={chatInput} onChange={e=>setChatInput(e.target.value)}/>
            <button style={S.chatSend} type="submit">→</button>
          </form>
        </div>
      )}
      <nav style={S.nav}>
        <button style={S.navBtn} onClick={()=>setTab("explore")}><span>⊞</span><span style={S.navLabel}>Explorer</span></button>
        <button style={S.navBtnOn}><span>💬</span><span style={S.navLabel}>Chat</span></button>
        <button style={S.navBtn} onClick={()=>setTab("profile")}><span>◯</span><span style={S.navLabel}>Profil</span></button>
      </nav>
    </div>
  );

  // ── PROFILE ──
  if (tab==="profile") return (
    <div style={S.app}><style>{CSS}</style>
      <header style={S.header}>
        <span style={S.headerTitle}>Mon Profil</span>
        {user&&(<div style={S.bellWrap} onClick={()=>setShowUserNotifs(!showUserNotifs)}><button style={S.bell}>🔔</button>{unreadUser>0&&<div style={S.bellBadge}>{unreadUser}</div>}</div>)}
      </header>
      {showUserNotifs&&user&&(<div style={{...S.notifPanel,right:12}}><div style={{padding:"14px 16px",borderBottom:"1px solid #222",fontSize:12,color:"#e74c3c",fontWeight:700,textTransform:"uppercase",letterSpacing:1}}>Nouveautés</div>{userNotifs.length===0&&<div style={{padding:20,color:"#555",fontSize:13,textAlign:"center"}}>Aucune nouvelle ref</div>}{userNotifs.map(n=>(<div key={n.id} style={S.notifItem}><div style={S.notifTitle}>🖼️ Nouvelle référence</div><div style={S.notifSub}>"{n.title}" — {n.artist}</div><div style={S.notifSub}>Dans : {n.movement}</div><div style={S.notifSub}>Par : {n.addedBy}</div></div>))}<button style={{...S.skipBtn,padding:"12px 0",borderTop:"1px solid #1a1a1a"}} onClick={()=>{localStorage.setItem("artref_notifs_lastseen",Date.now());setUserNotifs([]);setShowUserNotifs(false);}}>Tout marquer comme lu</button></div>)}

      {editingProfile&&user&&(<div style={S.modalBack}><div style={S.modal}><h3 style={S.modalTitle}>Modifier mon profil</h3><form onSubmit={saveProfile} style={{display:"flex",flexDirection:"column",gap:12}}><textarea style={{...S.inputFull,height:100,resize:"vertical"}} placeholder="Ta bio..." value={profileForm.bio} onChange={e=>setProfileForm({...profileForm,bio:e.target.value})}/><div style={S.row}><button style={S.btnRed} type="submit">Sauvegarder</button><button style={S.btnOutline} type="button" onClick={()=>setEditingProfile(false)}>Annuler</button></div></form></div></div>)}

      {user?(
        <div style={S.profileWrap}>
          <div style={S.avatarWrap} onClick={()=>avatarInputRef.current?.click()}>
            <Avatar user={user} size={90}/>
            <div style={{position:"absolute",bottom:0,right:0,background:"#e74c3c",borderRadius:"50%",width:26,height:26,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13}}>📷</div>
            {admin&&<div style={S.adminBadge}>ADMIN</div>}
          </div>
          <input ref={avatarInputRef} type="file" accept="image/*" style={{display:"none"}} onChange={handleAvatarChange}/>
          <div style={S.profileName}>{user.firstName} {user.lastName}</div>
          <div style={S.profileEmail}>{user.email}</div>
          {user.bio&&<div style={S.profileBio}>{user.bio}</div>}
          <div style={{display:"flex",gap:20,marginTop:12}}>
            <div style={{textAlign:"center"}}><div style={{fontSize:18,fontWeight:700,color:"#fff"}}>{following.length}</div><div style={{fontSize:11,color:"#555"}}>abonnements</div></div>
            <div style={{textAlign:"center"}}><div style={{fontSize:18,fontWeight:700,color:"#fff"}}>{followers.length}</div><div style={{fontSize:11,color:"#555"}}>abonnés</div></div>
          </div>
          <div style={{display:"flex",gap:10,marginTop:16}}>
            <button style={{...S.adminPanelBtn,marginTop:0}} onClick={()=>{setProfileForm({bio:user.bio||""});setEditingProfile(true);}}>✏️ Modifier</button>
            {admin&&<button style={{...S.adminPanelBtn,marginTop:0}} onClick={()=>setAdminPanel(true)}>⚙️ Admin</button>}
          </div>
          <div style={{width:"100%",marginTop:32}}>
            <div style={S.savedHeader}>Mes références sauvegardées ({saved.length})</div>
            {saved.length===0&&<p style={{color:"#555",textAlign:"center",marginTop:24,fontSize:13}}>Aucune référence sauvegardée.</p>}
            <div style={S.masonry}>
              {saved.map((ref,i)=>(<div key={ref.id} style={S.card}><img src={ref.photo||`https://picsum.photos/seed/sv${i}/400/400`} alt={ref.title} style={S.cardImg} onError={e=>{e.target.src=`https://picsum.photos/seed/sv${i}/400/400`;}} /><div style={S.cardBody}>{ref.movement&&<span style={S.mvBadge}>{ref.movement}</span>}<div style={S.cardTitle}>{ref.title}</div><div style={S.cardArtist}>{ref.artist}</div><button style={S.unsaveBtn} onClick={()=>setSaved(saved.filter(s=>s.id!==ref.id))}>Retirer</button></div></div>))}
            </div>
          </div>
          <button style={S.logoutBtn} onClick={logout}>Se déconnecter</button>
        </div>
      ):(
        <div style={S.profileWrap}>
          <div style={{width:80,height:80,borderRadius:"50%",background:"#1a1a1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:32}}>?</div>
          <p style={{color:"#666",marginTop:16,fontSize:14}}>Connecte-toi pour accéder à ton profil.</p>
          <button style={{...S.btnRed,marginTop:20,width:200}} onClick={()=>setAuthMode("login")}>Se connecter</button>
        </div>
      )}
      <nav style={S.nav}>
        <button style={S.navBtn} onClick={()=>setTab("explore")}><span>⊞</span><span style={S.navLabel}>Explorer</span></button>
        <button style={S.navBtn} onClick={()=>setTab("chat")}><span>💬</span><span style={S.navLabel}>Chat</span></button>
        <button style={S.navBtnOn}><span>◯</span><span style={S.navLabel}>Profil</span></button>
      </nav>
    </div>
  );

  // ── EXPLORE ──
  return (
    <div style={S.app}><style>{CSS}</style>
      <header style={S.header}>
        <div style={S.logo}>ARTREF</div>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          {!user&&<button style={S.loginBtn} onClick={()=>setAuthMode("login")}>Connexion</button>}
          {admin&&<button style={S.adminBtn} onClick={()=>setAdminPanel(true)}>⚙️</button>}
        </div>
      </header>
      <div style={S.searchWrap}>
        <span style={{fontSize:16,color:"#555"}}>🔍</span>
        <input style={S.searchInput} placeholder="Rechercher un mouvement..." value={search} onChange={e=>setSearch(e.target.value)}/>
        {search&&<button style={S.searchClear} onClick={()=>setSearch("")}>✕</button>}
      </div>
      {filtered.length===0&&(<div style={S.noResult}><p style={{fontSize:32}}>🔎</p><p style={{color:"#555",fontSize:14,marginTop:8}}>Aucun mouvement trouvé pour "{search}"</p></div>)}
      <div style={S.grid}>
        {filtered.map(m=>(<div key={m.id} style={S.movCard} onClick={()=>{setSelectedMovement(m);loadRefs(m);}}><img src={m.cover||`https://picsum.photos/seed/mv-${m.id}/600/400`} alt={m.name} style={S.movImg} onError={e=>{e.target.src=`https://picsum.photos/seed/mv-${m.id}/600/400`;}} /><div style={S.movOverlay}><div style={S.movName}>{m.name}</div><div style={S.movYears}>{m.years}</div></div></div>))}
      </div>
      <nav style={S.nav}>
        <button style={S.navBtnOn}><span>⊞</span><span style={S.navLabel}>Explorer</span></button>
        <button style={S.navBtn} onClick={()=>setTab("chat")}><span>💬</span><span style={S.navLabel}>Chat</span></button>
        <button style={S.navBtn} onClick={()=>setTab("profile")}><span>◯</span><span style={S.navLabel}>Profil</span></button>
      </nav>
    </div>
  );
}
